﻿
// ============================================================================
// FILE: Core/StoryManager.cs — VERSION 3.2
//
// ELEVATION MODEL (definitive — no foundation zone concept):
//
//   SetStories_2 base = 0.0  → ETABS "Base" row = 0m  ✓
//
//   Stories stack from 0 using user-supplied heights exactly:
//     Basement1 : height=1.5  → base=0.0,  top=1.5
//     Podium1   : height=3.5  → base=1.5,  top=5.0
//     Ground    : height=4.0  → base=5.0,  top=9.0
//     ...
//
//   Walls:  placed at baseElevation, height = storyHeight  (always)
//   Slabs:  placed at baseElevation + 0.005                (always)
//
//   The "foundationHeight" parameter is accepted for backward compatibility
//   but is completely ignored — the caller must pass it as Basement1's
//   story height in storyHeights[0] instead.
//
// CHANGES from v3.1:
//   - foundationHeight param accepted but ignored (no longer used anywhere).
//   - cumulativeHeight starts at 0.0 (unchanged from v3.1).
//   - SetStories_2 base = 0.0 (unchanged from v3.1).
//   - FoundationHeight public property removed.
//   - All foundation-zone special casing eliminated.
// ============================================================================

using ETABSv1;
using System;
using System.Collections.Generic;

namespace ETAB_Automation.Core
{
    public class StoryManager
    {
        private readonly cSapModel sapModel;

        private Dictionary<int, double> storyBaseElevations;
        private Dictionary<int, double> storyTopElevations;
        private Dictionary<string, int> storyNameToIndex;
        private List<string> storyNames;
        private List<double> storyUserHeights;

        public StoryManager(cSapModel model)
        {
            sapModel = model;
            storyBaseElevations = new Dictionary<int, double>();
            storyTopElevations = new Dictionary<int, double>();
            storyNameToIndex = new Dictionary<string, int>();
            storyNames = new List<string>();
            storyUserHeights = new List<double>();
        }

        // ====================================================================
        // PRIMARY METHOD
        // foundationHeight is accepted for API compatibility but ignored.
        // The caller passes Basement1's actual height in storyHeights[0].
        // ====================================================================
        public void DefineStoriesWithCustomNames(
            List<double> storyHeights,
            List<string> storyNames,
            double foundationHeight = 0.0)   // ignored — kept for API compat only
        {
            if (storyHeights == null || storyNames == null)
                throw new ArgumentNullException("Story heights or names cannot be null");
            if (storyHeights.Count != storyNames.Count)
                throw new ArgumentException(
                    $"Story heights ({storyHeights.Count}) and names ({storyNames.Count}) count mismatch");
            if (storyHeights.Count == 0)
                throw new ArgumentException("Cannot define zero stories");
            for (int i = 0; i < storyHeights.Count; i++)
                if (storyHeights[i] <= 0.0)
                    throw new ArgumentException(
                        $"Story '{storyNames[i]}' height must be > 0.");

            sapModel.SetModelIsLocked(false);
            System.Diagnostics.Debug.WriteLine("\n========== UNIT SYSTEM CHECK ==========");
            sapModel.SetPresentUnits(eUnits.N_m_C);
            System.Diagnostics.Debug.WriteLine($"Units: {sapModel.GetPresentUnits()}");
            System.Diagnostics.Debug.WriteLine("=========================================\n");

            int numStories = storyHeights.Count;
            this.storyNames = new List<string>(storyNames);
            this.storyUserHeights = new List<double>(storyHeights);
            storyBaseElevations.Clear();
            storyTopElevations.Clear();
            storyNameToIndex.Clear();

            string[] names = new string[numStories];
            double[] elevs = new double[numStories];
            bool[] master = new bool[numStories];
            string[] similar = new string[numStories];
            bool[] splice = new bool[numStories];
            double[] spliceHt = new double[numStories];
            int[] colors = new int[numStories];

            double cumulativeHeight = 0.0;   // always starts at 0

            System.Diagnostics.Debug.WriteLine("\n========== STORY ELEVATIONS ==========");
            System.Diagnostics.Debug.WriteLine("ETABS Base: 0.000m");

            for (int i = 0; i < numStories; i++)
            {
                names[i] = storyNames[i];
                master[i] = true;
                similar[i] = null;
                splice[i] = false;
                spliceHt[i] = 0.0;
                colors[i] = AssignColorByStoryType(storyNames[i]);

                storyBaseElevations[i] = cumulativeHeight;
                storyNameToIndex[storyNames[i]] = i;
                elevs[i] = storyHeights[i];
                storyTopElevations[i] = cumulativeHeight + storyHeights[i];
                cumulativeHeight += storyHeights[i];

                System.Diagnostics.Debug.WriteLine(
                    $"Story {i}: {storyNames[i].PadRight(14)} | " +
                    $"Base={storyBaseElevations[i]:F3}m  " +
                    $"Height={storyHeights[i]:F3}m  " +
                    $"Top={storyTopElevations[i]:F3}m");
            }

            System.Diagnostics.Debug.WriteLine($"Top of building: {cumulativeHeight:F3}m");
            System.Diagnostics.Debug.WriteLine("======================================\n");

            int ret = sapModel.Story.SetStories_2(
                0.0,            // Base always = 0 ✓
                numStories,
                ref names, ref elevs,
                ref master, ref similar,
                ref splice, ref spliceHt, ref colors);

            if (ret != 0)
                throw new Exception($"ETABS SetStories_2 failed. Error code: {ret}");

            System.Diagnostics.Debug.WriteLine("\n========== VERIFYING ETABS ==========");
            for (int i = 0; i < numStories; i++)
            {
                double storedElev = 0;
                if (sapModel.Story.GetElevation(names[i], ref storedElev) == 0)
                {
                    string status = Math.Abs(storedElev - storyTopElevations[i]) < 0.001 ? "✓" : "⚠";
                    System.Diagnostics.Debug.WriteLine(
                        $"  {names[i].PadRight(14)}: top={storedElev:F3}m  {status}");
                }
            }
            System.Diagnostics.Debug.WriteLine("=====================================\n");

            VerifyStories();
            sapModel.View.RefreshView(0, true);
        }

        // ====================================================================
        // ACCESSORS
        // ====================================================================

        public double GetStoryBaseElevation(int storyIndex)
        {
            if (!storyBaseElevations.ContainsKey(storyIndex))
                throw new ArgumentException($"Story index {storyIndex} not found.");
            return storyBaseElevations[storyIndex];
        }

        public double GetStoryTopElevation(int storyIndex)
        {
            if (!storyTopElevations.ContainsKey(storyIndex))
                throw new ArgumentException($"Story index {storyIndex} not found.");
            return storyTopElevations[storyIndex];
        }

        public double GetStoryHeight(int storyIndex)
            => GetStoryTopElevation(storyIndex) - GetStoryBaseElevation(storyIndex);

        public string GetStoryNameByIndex(int storyIndex)
        {
            if (storyIndex >= 0 && storyIndex < storyNames.Count)
                return storyNames[storyIndex];
            throw new ArgumentException($"Story index {storyIndex} out of range");
        }

        public int GetStoryIndexByName(string storyName)
        {
            if (storyNameToIndex.ContainsKey(storyName))
                return storyNameToIndex[storyName];
            throw new ArgumentException($"Story name '{storyName}' not found");
        }

        public int GetStoryCount() => storyBaseElevations.Count;

        public double GetTotalBuildingHeight()
            => storyTopElevations.Count == 0 ? 0 : storyTopElevations[storyTopElevations.Count - 1];

        // ====================================================================
        // PRIVATE HELPERS
        // ====================================================================

        private int AssignColorByStoryType(string name)
        {
            if (name.StartsWith("Basement")) return 255;
            if (name.StartsWith("Podium")) return 65280;
            if (name == "Ground") return 16776960;
            if (name == "EDeck") return 16776960;
            if (name.StartsWith("Story")) return 16711680;
            if (name.StartsWith("Refuge")) return 16744448;
            if (name == "Terrace") return 16711935;
            return -1;
        }

        private void VerifyStories()
        {
            int n = 0; string[] names = null;
            sapModel.Story.GetNameList(ref n, ref names);
            System.Diagnostics.Debug.WriteLine($"ETABS story count: {n}");
            if (names != null)
                foreach (string s in names)
                {
                    double elev = 0;
                    sapModel.Story.GetElevation(s, ref elev);
                    System.Diagnostics.Debug.WriteLine($"  {s}: top={elev:F3}m");
                }
        }

        // ====================================================================
        // LEGACY COMPAT
        // ====================================================================

        public void DefineStoriesWithVariableHeights(List<double> storyHeights)
        {
            var names = new List<string>();
            for (int i = 0; i < storyHeights.Count; i++) names.Add($"Story{i + 1}");
            DefineStoriesWithCustomNames(storyHeights, names);
        }

        public void DefineStories(int numStories, double storyHeight)
        {
            var heights = new List<double>();
            var names = new List<string>();
            for (int i = 0; i < numStories; i++) { heights.Add(storyHeight); names.Add($"Story{i + 1}"); }
            DefineStoriesWithCustomNames(heights, names);
        }

        public string GetStoryName(int storyIndex)
        {
            if (storyIndex >= 0 && storyIndex < storyNames.Count) return storyNames[storyIndex];
            return storyIndex == 0 ? "Base" : $"Story{storyIndex + 1}";
        }

        public double GetStoryElevation(int story, double storyHeight) => story * storyHeight;

        public double GetStoryElevationVariable(List<double> storyHeights, int storyIndex)
        {
            if (storyBaseElevations.ContainsKey(storyIndex)) return GetStoryBaseElevation(storyIndex);
            if (storyIndex == 0) return 0.0;
            double elev = 0;
            for (int i = 0; i < storyIndex && i < storyHeights.Count; i++) elev += storyHeights[i];
            return elev;
        }

        public double GetETABSStoryElevation(string storyName)
        {
            double e = 0;
            if (sapModel.Story.GetElevation(storyName, ref e) == 0) return e;
            throw new Exception($"Could not retrieve ETABS elevation for '{storyName}'");
        }
    }
}
